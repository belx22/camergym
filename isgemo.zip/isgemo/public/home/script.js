const   form = document.querySelector("form"),
        nextBtn = form.querySelector(".nextBtn"),
        predBtn = form.querySelector(".predBtn"),
        allInput = form.querySelectorAll(".first input");


nextBtn.addEventListener("click",()=>{
    allInput.forEach(input =>{
        if(input.value != ""){
            form.classList.add('secActive');
        }else{
           form.classList.remove('secActive');            
        }
    })
})

predBtn.addEventListener("click",()=> form.classList.remove('secActive'));
