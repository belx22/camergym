<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation du Processus</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .headerTitre {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}


.home-button {
    display: inline-block;
}

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        .input-field {
            margin: 10px 0;
            width: 755;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        .button a{
            text-decoration: none;
            color: white;
        }

        .button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            width: 50%;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .explanation {
            margin-bottom: 15px;
            font-size: 14px;
            color: #555;
        }
        @media (max-width: 600px) {
            .explanation {
                font-size: 12px; /* Ajuste la taille de la police pour les petits écrans */
            }
            .input-field {
                font-size: 14px; /* Ajuste la taille de la police des champs de saisie */
            }
            .button {
                font-size: 14px; /* Ajuste la taille de la police du bouton */
            }
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
</head>
<body>

<div class="container">
    <div class="headerTitre">
        <h2>ISGEMO</h2>
        <a href="index.html" class="home-button">
            <img src="img/home-icon.png" alt="Accueil" width="40" height="40">
        </a>
    </div>
    <h2>Validation du Processus</h2>
    <div class="explanation">
        Veuillez entrer les deux codes ci-dessous pour valider le processus. Un PDF sera généré avec vos informations.
    </div>
    <input type="text" id="code1" class="input-field" placeholder="Entrez le premier code" required>
    <input type="text" id="code2" class="input-field" placeholder="Entrez le deuxième code" required>
    <button class="button" onclick="generatePDF()">Générer le PDF</button>
    <button class="button"><a href="inscriptPage.html">Annuler</a></button>
</div>

</body>
</html>