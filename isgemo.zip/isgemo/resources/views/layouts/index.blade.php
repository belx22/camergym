<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>ISGEMO - Le choix de la reussite</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

        <!-- Favicon -->
        <link href="{{ url('home/img/favicon.ico')}}" rel="icon">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">
    
        <!-- Icon Font Stylesheet -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    
        <!-- Libraries Stylesheet -->
        <link href="{{ url('home/lib/animate/animate.min.css')}}" rel="stylesheet">
        <link href="{{ url('home/lib/owlcarousel/assets/owl.carousel.min.css')}}" rel="stylesheet">
    
        <!-- Customized Bootstrap Stylesheet -->
        <link href="{{ url('home/css/bootstrap.min.css')}}" rel="stylesheet">
    
        <!-- Template Stylesheet -->
        <link href="{{ url('home/css/style.css')}}" rel="stylesheet">
        <link href="{{ url('home/css/styleCraint.css')}}" rel="stylesheet">
    

    <style>
        
        .filiere {
            background: #e3f2fd;
            padding: 15px;
            margin: 20px 0;
            border-left: 5px solid #06BBCC;
        }
        .filiere h2 {
            margin: 0;
            color: #06BBCC;
        }
        .details {
            padding: 10px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        .cta {
            text-align: center;
            margin-top: 10px;
        }
        .cta a {
            display: inline-block;
            padding: 10px 20px;
            background: #06BBCC;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .cta a:hover {
            background: #0277bd;
        }
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 10px;
            }
        }
    </style>


</head>
<body>
    <!-- Spinner Start -->
  
    <!-- Spinner End -->

    @include('layouts.partials.nav')

                 @yield('content')

    @include('layouts.partials.footer')

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ url('home/lib/wow/wow.min.js')}}"></script>
    <script src="{{ url('home/lib/easing/easing.min.js')}}"></script>
    <script src="{{ url('home/lib/waypoints/waypoints.min.js')}}"></script>
    <script src="{{ url('home/lib/owlcarousel/owl.carousel.min.js')}}"></script>

    <!-- jQery -->
  <script type="text/javascript" src="{{ url('home/js/jquery-3.4.1.min.js')}}"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script type="text/javascript" src="{{ url('home/js/bootstrap.js')}}"></script>
  <!-- owl slider -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- custom js -->
  <script type="text/javascript" src="{{ url('home/js/custom.js')}}"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->

    <!-- Template Javascript -->
    <script src="{{ url('home/js/main.js')}}"></script>
</body>

</html>
