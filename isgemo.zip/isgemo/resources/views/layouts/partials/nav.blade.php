   <!-- Navbar Start -->
   <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 text-primary"><i class="fa fa-book me-3"></i>ISGEMO</h2>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="{{url('/')}}" class="nav-item nav-link active">Acceuil</a>
            <a href="{{url('/about')}}" class="nav-item nav-link">A propos</a>
            <a href="#filiere" class="nav-item nav-link">Filières</a>
            <a href="{{url('/apropos')}}" class="nav-item nav-link">Contact</a>
        </div>
        <a href="inscriptPage.html" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">S'INSCRIRE<i class="fa fa-arrow-right ms-3"></i></a>
    </div>
</nav>
<!-- Navbar End -->