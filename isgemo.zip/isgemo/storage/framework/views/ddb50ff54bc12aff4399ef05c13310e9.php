<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(url('home/styles.css')); ?>">
    <!-- <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0./css/line.css"> -->

    <title>Document</title>
</head>
<body>

    <div class="container">
        <div class="headerTitre">
            <h2>ISGEMO</h2>
            <a href="index.html" class="home-button">
                <img src="img/exit.png" alt="Accueil" width="40" height="40">
            </a>
        </div>
        <header>
            Formulaire de Pre-inscription
        </header>

        <form action="#">
            <div class="form first">
                <!-- Premier formulaire-->
                <div class="details choix">
                    
                    <span class="title">Choix filière</span>

                    <div class="fieldChoix">

                        <div class="input-field">
                            <label>Filière 1 :</label>
                            <select name="filiere1" id="">
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                            </select>
                        </div>
    
                         <div class="input-field">
                            <label>Spécialité 1 :</label>
                            <select name="filiere1" id="">
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                            </select>
                        </div>
    
                        <div class="input-field">
                            <label>Filière 2 :</label>
                            <select name="filiere2" id="">
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                            </select>
                        </div>
    
                        <div class="input-field">
                            <label>Spécialité 2:</label>
                            <select name="spec2" id="">
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                                <option value="marie">Mariée</option>
                            </select>
                        </div>
                    </div>


                </div>
                <div class="details personal">
                    <span class="title">Identification</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Noms :</label>
                            <input type="text" placeholder="Noms" >
                        </div>

                        <div class="input-field">
                            <label>Prenoms :</label>
                            <input type="text" placeholder="Prenoms"  >
                        </div>

                        <div class="input-field">
                            <label>Date de naissance :</label>
                            <input type="date" placeholder="Date de naissance" >
                        </div>

                        <div class="input-field">
                            <label>Lieu de naissance :</label>
                            <input type="text" placeholder="Lieu de naissance" >
                        </div>

                        <div class="input-field" >
                            <label>Sexe :</label>
                            <!-- <input list="sexe" name="sexe" placeholder="Choissiez votre sexe" >
                            <datalist id="sexe">
                                <option value="Feminin">
                                <option value="Masculin">
                            </datalist> -->
                            <select name="sexe">
                                <option value="Feminin">Feminin</option>
                                <option value="Masculin">Masculin</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Situation matrimonial :</label>
                            <!-- <input type="text" placeholder="Date de naissance"> -->
                            <select name="sexe">
                                <option value="celib">Celibataire</option>
                                <option value="mariee">Mariée</option>
                                <option value="veuve">Veuve</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Email :</label>
                            <input type="text" placeholder="Email">
                        </div>

                        <div class="input-field">
                            <label>Telephone :</label>
                            <input type="tel" placeholder="Numero de téléphone">
                        </div>

                        <div class="input-field">
                            <label>Pays d'origine :</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                        <div class="input-field">
                            <label>Photo 4x4 :</label>
                            <input type="file" accept="image/*" placeholder="Photo 4x4">
                        </div>

                        <div class="input-field">
                            <label>Numéro CNI:</label>
                            <input type="number" placeholder="Numero de téléphone">
                        </div>

                        <div class="input-field">
                            <label>Date d'expiration CNI:</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                    </div>
                </div>

                
                <div class="details ID">
                    <span class="title">Information Detaillés</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Noms et Prenoms du pére/tuteur :</label>
                            <input type="text" placeholder="Noms et Prenoms du pére/tuteur">
                        </div>

                        <div class="input-field">
                            <label>Numéro téléphone :</label>
                            <input type="tel" placeholder="Numéro téléphone">
                        </div>

                        <div class="input-field">
                            <label>Region d'origine :</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                        <div class="input-field">
                            <label>Noms et Prenoms de la mére/tutrice :</label>
                            <input type="text" placeholder="Noms et Prenoms de la mére/tutrice">
                        </div>

                        <div class="input-field">
                            <label>Numéro téléphone :</label>
                            <input type="tel" placeholder="Numéro téléphone">
                        </div>

                        <div class="input-field">
                            <label>Region d'origine :</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                    </div>
                </div>

                <div class="button">

                    <button class="nextBtn">
                        <span class="btnText">Suivant</span>
                        <i class="uil uil-navigator"></i>
                    </button>

                </div>

            </div>

            <!--Deuxieme formulaire -->

            <div class="form second">
                <div class="details personal">
                    <span class="title">Parcours Scolaire Secondaire</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Etablissement:</label>
                            <input type="text" placeholder="Noms" >
                        </div>

                        <div class="input-field">
                            <label>Classe / Diplome obtenu :</label>
                            <input type="text" placeholder="Prenoms" >
                        </div>

                        <div class="input-field">
                            <label>Année académique :</label>
                            <input type="date" placeholder="Date de naissance" >
                        </div>

                        <div class="input-field">
                            <label>Etablissement :</label>
                            <input type="text" placeholder="Lieu de naissance" >
                        </div>

                        <div class="input-field" >
                            <label>Classe / Diplome obtenu :</label>
                            <input list="sexe" name="sexe" placeholder="Choissiez votre sexe" >
                            <datalist id="sexe">
                                <option value="Feminin">
                                <option value="Masculin">
                            </datalist>
                        </div>

                        <div class="input-field">
                            <label>Année académique :</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                        <div class="input-field">
                            <label>Etablissement:</label>
                            <input type="text" placeholder="Email">
                        </div>

                        <div class="input-field">
                            <label>Classe / Diplome obtenu :</label>
                            <input type="tel" placeholder="Numero de téléphone">
                        </div>

                        <div class="input-field">
                            <label>Année académique:</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                    </div>
                </div>

                <div class="details ID">
                    <span class="title">Parcours Scolaire Supérieur</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Etablissement :</label>
                            <input type="text" placeholder="Noms et Prenoms du pére/tuteur">
                        </div>

                        <div class="input-field">
                            <label>Niveau / Diplome obtenu :</label>
                            <input type="tel" placeholder="Numéro téléphone">
                        </div>

                        <div class="input-field">
                            <label>Année académique :</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                        <div class="input-field">
                            <label>Etablissement :</label>
                            <input type="text" placeholder="Noms et Prenoms du pére/tuteur">
                        </div>

                        <div class="input-field">
                            <label>Niveau / Diplome obtenu :</label>
                            <input type="tel" placeholder="Numéro téléphone">
                        </div>

                        <div class="input-field">
                            <label>Année académique :</label>
                            <input type="date" placeholder="Date de naissance">
                        </div>

                    </div>
                </div>

                <div class="details ID">
                    <span class="title">Parcours Professionnel</span>

                    <div class="fields">

                        <div class="input-field">
                            <label>Noms de l'entreprise :</label>
                            <input type="text" placeholder="Noms et Prenoms du pére/tuteur">
                        </div>

                        <div class="input-field">
                            <label>Poste occupé:</label>
                            <input type="tel" placeholder="Numéro téléphone">
                        </div>

                        <div class="input-field">
                            <label>Durée :</label>
                            <input type="date" ">
                        </div>

                       <div class="input-field">
                            <label>Noms de l'entreprise :</label>
                            <input type="text" placeholder="Noms et Prenoms du pére/tuteur">
                        </div>

                        <div class="input-field">
                            <label>Poste occupé:</label>
                            <input type="tel" placeholder="Numéro téléphone">
                        </div>

                        <div class="input-field">
                            <label>Durée :</label>
                            <input type="date" ">
                        </div>

                    </div>
                </div>

                <div class="buttons">

                    <div class="predBtn">
                        <span class="btnText">Precedent</span>
                        <i class="uil uil-navigator"></i>
                    </div>

                    <button class="nextBtn">
                        <span class="btnText">Soumettre</span>
                        <i class="uil uil-navigator"></i>
                    </button>

                </div>

            </div>

            

        </form>

    </div>

    <script src="script.js"></script>
    
</body>
</html><?php /**PATH /home/bello/Bureau/laravel app/isgemo/resources/views/home/formulaire.blade.php ENDPATH**/ ?>