<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Préinscription</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="container">
        <div class="header">
            <h2>ISGEMO</h2>
            <a href="index.html" class="home-button">
                <img src="img/home-icon.png" alt="Accueil" width="50" height="50">
            </a>
        </div>

        <div class="documents">
            <h3>Pièces à fournir pour la préinscription :</h3>
            <ul>
                <li>Copie de la carte d'identité</li>
                <li>Diplôme ou relevé de notes</li>
                <li>Photo d'identité récente</li>
                <li>Formulaire de préinscription rempli</li>
            </ul>
        </div>
        <br>
        <p>Choisissez une option :</p>
        <div class="options">
            <button onclick="location.href='<?php echo e(url('/formulaire')); ?>'">Nouvelle Inscription</button>
            <button onclick="location.href='<?php echo e(url('/finalPreinscrip')); ?>'">Finaliser l'Inscription</button>
        </div>
    </div>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #f4f4f4;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .home-button {
            display: inline-block;
        }

        .options {
            margin-top: 1.5rem;
        }

        button {
            width: 75%;
            padding: 0.7rem;
            margin: 0.5rem 0;
            background: #06BBCC;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        button:hover {
            background: #0056b3;
        }

        .documents {
            margin-top: 2rem;
            text-align: left;
        }

        .documents h3 {
            margin-bottom: 0.5rem;
        }

        .documents ul {
            list-style-type: disc;
            padding-left: 20px;
        }
    </style>
</body>
</html>
<?php /**PATH /home/bello/Bureau/laravel app/isgemo/resources/views/home/inscrit.blade.php ENDPATH**/ ?>