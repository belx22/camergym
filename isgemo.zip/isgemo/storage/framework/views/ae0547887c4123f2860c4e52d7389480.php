<?php $__env->startSection('content'); ?>

    <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5">
        <div class="owl-carousel header-carousel position-relative">
            <div class="owl-carousel-item position-relative">
                <img class="img-fluid" src="<?php echo e(url('home/img/batIS.jpg')); ?>" alt="">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(24, 29, 56, .7);">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-sm-10 col-lg-8">
                                <h5 class="text-primary text-uppercase mb-3 animated slideInDown">Le choix de la réussite</h5>
                                <h1 class="display-3 text-white animated slideInDown">INSTITUT SUPERIEUR GERMINAL DE MOKOLO</h1>
                                <p class="fs-5 text-white mb-4 pb-2">Autorisation Spéciale No 24-00048/L/MINESUP/SG/DDES/ESUP/SDA/AOSB</p>
                                <a href="about.html" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">En Savoir plus</a>
                                <a href="inscriptPage.html" class="btn btn-light py-md-3 px-md-5 animated slideInRight">S'inscrire</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <!-- Carousel End -->
 


    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="<?php echo e(url('home/img/about.jpeg')); ?>" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">A propos de nous</h6>
                    <h1 class="mb-4">Bienvenue à ISGEMO</h1>
                    <p class="mb-4">Notre vision est de créer une communauté académique et professionnelle qui forme des leaders et des entrepreneurs 
                        capables de relever les défis économiques, sociaux et environnementaux de demain.
                         Nous souhaitons être reconnus comme l'un des meilleurs Institut privé d’enseignement 
                         Supérieur dans la région de l’Extrême-Nord, au Cameroun voire dans la sous-région Afrique centrale, 
                         en termes de qualité de l'enseignement, de la recherche et de l'innovation </p>

                    <p class="mb-4">À ISGEMO, nous guidons notre institution selon des valeurs fondamentales qui façonnent notre approche académique
                         et professionnelle :</p>
                    <div class="row gy-2 gx-4 mb-4">
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i><b>Excellence :</b>Des formations et services de haute qualité pour une réussite assurée.</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i><b>Innovation :</b>Créativité et entrepreneuriat au cœur de notre pédagogie.</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i><b>Responsabilité sociale :</b> Contribuer activement au développement de notre société.</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i><b>Diversité et inclusion :</b> Une communauté ouverte et inclusive pour tous.</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i><b>Intégrité :</b> Agir avec éthique et transparence dans toutes nos actions.</p>
                        </div>
                    </div>
                    <p class="mb-4"><b>Rejoignez-nous et bâtissez votre futur dès aujourd’hui !</b></p>
                    <!--  <a class="btn btn-primary py-3 px-5 mt-2" href="">Read More</a> -->
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

     <!-- Service Start -->
     <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3"></h6>
                <h1 class="mb-5">Nos atout à l'ISGEMO</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-graduation-cap text-primary mb-4"></i>
                            <h5 class="mb-3">Enseignant Qualifié</h5>
                            <p style="text-align: justify;">À ISGEMO, nos enseignants allient expertise académique et pratique. Engagés et innovants, 
                                ils forment des leaders prêts à relever les défis du monde professionnel grâce à un enseignement 
                                interactif et adapté aux réalités du marché. Leur encadrement personnalisé garantit une formation 
                                d’excellence.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-globe text-primary mb-4"></i>
                            <h5 class="mb-3">Cours En Ligne</h5>
                            <p style="text-align: justify;">ISGEMO propose des cours en ligne flexibles et interactifs. Dispensés par des experts, ils allient théorie 
                                et pratique avec des supports modernes et un suivi personnalisé. Étudiants et professionnels peuvent ainsi 
                                acquérir des compétences essentielles à leur rythme, tout en bénéficiant d’un encadrement de qualité.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-home text-primary mb-4"></i>
                            <h5 class="mb-3">Travaux Pratique</h5>
                            <p style="text-align: justify;">À ISGEMO, les travaux pratiques sont essentiels. Grâce à des simulations, études de cas et projets concrets, 
                                nos étudiants appliquent leurs connaissances sous l’encadrement d’experts. Cette approche développe l’autonomie, 
                                l’innovation et la maîtrise des outils modernes pour une insertion réussie.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-book-open text-primary mb-4"></i>
                            <h5 class="mb-3">Bibliotheque</h5>
                            <p style="text-align: justify;">La bibliothèque d’ISGEMO offre un large accès à des ouvrages, revues et ressources numériques de qualité. Moderne et 
                                bien équipée, elle favorise la recherche et l’apprentissage. Un espace idéal pour étudier, approfondir ses connaissances 
                                et innover dans un environnement propice à l’excellence académique.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->

    
    <!-- Categories Start -->
     
    <div class="container-xxl py-5 category" id="filiere">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3"></h6>
                <h1 class="mb-5">Nos Filières , Cycles et Spécialités à l'ISGEMO de Mokolo</h1>
            </div>
        </div>

        <div class="filiere">
            <h2>Gestion</h2>
            <div class="details">
                <p><strong>Cycle :</strong> BTS, Licence, Master</p>
                <p><strong>Spécialités :</strong></p>
                <ul>
                    <li>Management des Projets</li>
                    <li>Gestion des Ressources Humaines</li>
                    <li>Comptabilité et Gestion des Entreprises</li>
                    <li>Gestion de la Qualité</li>
                    <li>Banque et Finance</li>
                </ul>
                <p><strong>Débouchés :</strong> Chef de projet, Responsable RH, Comptable, Consultant, Responsable logistique</p>
                <p><strong>Durée :</strong> BTS - 2 ans, Licence - 3 ans, Master - 1 an</p>
                <p><strong>Frais d'inscription :</strong> 10 000 FCFA</p>
                <p><strong>Frais de scolarité :</strong> BTS - 360 000 FCFA, Licence - 410 000 FCFA, Master - 575 000 FCFA</p>
                <div class="cta">
                    <a href="#">S'inscrire</a>
                </div>
            </div>
        </div>

        <div class="filiere">
            <h2>Commerce</h2>
            <div class="details">
                <p><strong>Cycle :</strong> BTS</p>
                <p><strong>Spécialités :</strong></p>
                <ul>
                    <li>Marketing-Commerce-Vente</li>
                    <li>Commerce International</li>
                </ul>
                <p><strong>Débouchés :</strong> Agent de transit, Gestionnaire logistique, Inspecteur des douanes</p>
                <p><strong>Durée :</strong> 2 ans</p>
                <p><strong>Frais d'inscription :</strong> 10 000 FCFA</p>
                <p><strong>Frais de scolarité :</strong> 360 000 FCFA</p>
                <div class="cta">
                    <a href="#">S'inscrire</a>
                </div>
            </div>
        </div>

        <div class="filiere">
            <h2>Carrières Juridiques</h2>
            <div class="details">
                <p><strong>Cycle :</strong> BTS, CAPA</p>
                <p><strong>Spécialités :</strong></p>
                <ul>
                    <li>Assistant Juridique</li>
                    <li>Droit des Affaires et de l'Entreprise</li>
                    <li>Gestion Fiscale</li>
                    <li>Professions Immobilières</li>
                    <li>Droit Foncier et Domanial</li>
                </ul>
                <p><strong>Débouchés :</strong> Assistant juridique, Conseiller en droit, Agent immobilier</p>
                <p><strong>Durée :</strong> 2 ans</p>
                <p><strong>Frais d'inscription :</strong> 10 000 FCFA</p>
                <p><strong>Frais de scolarité :</strong> BTS - 360 000 FCFA, CAPA - 160 000 FCFA</p>
                <div class="cta">
                    <a href="#">S'inscrire</a>
                </div>
            </div>
        </div>

        <div class="filiere">
            <h2>Sciences Biomédicales et Médico-Sanitaires</h2>
            <div class="details">
                <p><strong>Cycle :</strong> BTS, Licence, Master</p>
                <p><strong>Spécialités :</strong></p>
                <ul>
                    <li>Sciences Infirmières</li>
                    <li>Sage-Femme</li>
                    <li>Techniques de Laboratoire et Analyse Médicale</li>
                </ul>
                <p><strong>Débouchés :</strong> Infirmier, Analyste biomédical, Responsable de laboratoire</p>
                <p><strong>Durée :</strong> BTS - 2 ans, Licence - 3 ans, Master - 1 an</p>
                <p><strong>Frais d'inscription :</strong> 10 000 FCFA</p>
                <p><strong>Frais de scolarité :</strong> BTS - 360 000 FCFA, Licence - 410 000 FCFA, Master - 575 000 FCFA</p>
                <div class="cta">
                    <a href="#">S'inscrire</a>
                </div>
            </div>
        </div>

     <div class="filiere">

            <h2>Certification</h2>
            <div class="details">
                <p><strong>Cycle :</strong> Certification</p>
                <p><strong>Spécialités :</strong></p>
                <ul>
                    <li>Gestion de la Décentralisation</li>
                </ul>
                <p><strong>Débouchés :</strong> Consultant en gestion des collectivités territoriales, Responsable des projets de développement local</p>
                <p><strong>Durée :</strong> 1 an</p>
                <p><strong>Frais d'inscription :</strong> 10 000 FCFA</p>
                <p><strong>Frais de scolarité :</strong> 160 000 FCFA</p>
                <div class="cta">
                    <a href="#">S'inscrire</a>
                </div>
            </div>
        </div>


    </div>
    
    <!-- Categories Start -->



    
  <!-- contact section -->
  <section class="contact_section">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-4 col-md-5 offset-md-1">
          <div class="heading_container">
            <h2>
              Contacter Nous
            </h2>
          </div>
        </div>
      </div>
      <div class="row" >
        <div class="col-lg-4 col-md-5 offset-md-1" style="padding-bottom: 20px;">
          <div class="form_container contact-form">
            <form action="">
              <div>
                <input type="text" placeholder="Votre noms" />
              </div>
              <div>
                <input type="text" placeholder="Numéro telephone" />
              </div>
              <div>
                <input type="email" placeholder="Email" />
              </div>
              <div>
                <input type="text" class="message-box" placeholder="Votre message" />
              </div>
              <div class="btn_box">
                <button>
                  ENVOYER
                </button>
              </div>
            </form>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
            <div class="d-flex align-items-center mb-3"> 
                 <div class="d-flex align-items-center justify-content-center flex-shrink-0 bg-primary" style="width: 50px; height: 50px;">
                     <i class="fa fa-map-marker-alt text-white"></i>
                 </div>
                 <div class="ms-3">
                     <h5 class="text-primary">Notre Campus</h5>
                     <p class="mb-0">Ancienne-SONEL, à l’ENIEG Privée Bilingue VANDI Joseph de Mokolo .</p>
                 </div>
             </div>
             <div class="d-flex align-items-center mb-3">
                 <div class="d-flex align-items-center justify-content-center flex-shrink-0 bg-primary" style="width: 50px; height: 50px;">
                     <i class="fa fa-phone-alt text-white"></i>
                 </div>
                 <div class="ms-3">
                     <h5 class="text-primary">Appeler</h5>
                     <p class="mb-0">+237 691 259 372 <br> +237 675 881 066 <br> +237 655 235 753 <br> +237 693 274 645</p>
                 </div>
             </div>
             <div class="d-flex align-items-center">
                 <div class="d-flex align-items-center justify-content-center flex-shrink-0 bg-primary" style="width: 50px; height: 50px;">
                     <i class="fa fa-envelope-open text-white"></i>
                 </div>
                 <div class="ms-3">
                     <h5 class="text-primary">Email</h5>
                     <p class="mb-0">info@isgemo.cm</p>
                 </div>
                 
             </div>
         </div>
    </div>
  </section>
  <!-- end contact section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bello/Bureau/laravel app/isgemo/resources/views/home/home.blade.php ENDPATH**/ ?>