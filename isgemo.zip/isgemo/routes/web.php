<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('home.home');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});


Route::get('contact/',function(){


    return view('home.contact');
});



Route::get('formulaire/',function(){


    return view('home.formulaire');
});


Route::get('finalPreinscrip/',function(){


    return view('home.finalPreinscrip');
});

Route::get('/inscription', function(){

    return view("home.inscrit");
});

Route::get('apropos/',function(){


    return view('home.apropos');
});



require __DIR__.'/auth.php';
